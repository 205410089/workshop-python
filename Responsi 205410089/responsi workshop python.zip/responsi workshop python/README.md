# web_codvid19_python

Youtube : https://www.youtube.com/watch?v=KlUKtDnoIwA <br>
Template from Mr.Web Designer : https://www.youtube.com/watch?v=sYguu9_ouvE&t=214s <br>
thank you <3
